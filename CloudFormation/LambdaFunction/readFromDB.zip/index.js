const mysql = require("mysql2/promise");

function mapSearchTerm(term) {
  const mappings = {
    "under": "<",
    "less": "<",
    "less than": "<",
    "below": "<",
    "minute": "Mins",
    "minutes": "Mins"
  };

  let tokens = term.split(" ");
  tokens = tokens.map(token => mappings[token.toLowerCase()] || token);
  return tokens.join(" ");
}

exports.handler = async (event, context, callback) => {
  const connection = await mysql.createPool({
    host: process.env.RDS_HOSTNAME,
    port: process.env.RDS_PORT,
    user: process.env.RDS_USERNAME,
    password: process.env.RDS_PASSWORD,
    database: process.env.RDS_DATABASE
  });

  if (event.queryStringParameters !== null || event.multiValueQueryStringParameters !== null) {
    if (typeof event.queryStringParameters.name !== "undefined") {
      let searchTerm = mapSearchTerm(event.queryStringParameters.name);
      let sql = '';
      let minutes;

      if (searchTerm.includes('<')) {
        minutes = searchTerm.match(/\d+/)[0];
        sql = `SELECT * FROM recipes_kaggle WHERE Keywords REGEXP '<[[:space:]]*([0-9]|[1-3][0-9]|40)[[:space:]]*Mins' AND CONVERT(SUBSTRING_INDEX(SUBSTRING_INDEX(Keywords, '< ', -1), ' ', 1), UNSIGNED INTEGER) <= ${minutes} LIMIT 800;`;
      } else {
        sql = `SELECT * FROM recipes_kaggle WHERE Keywords LIKE '%${searchTerm}%' OR Ingredients LIKE '%${searchTerm}%' OR Name LIKE '%${searchTerm}%' LIMIT 800;`;
      }

      const [res, ] = await connection.execute(sql);
      const response = {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin':'*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(res)
      };
      
      connection.end();
      return response;
      
    } else if (typeof event.multiValueQueryStringParameters.recipeId !== "undefined") {
      const size = (event.multiValueQueryStringParameters.recipeId.length < 18) ? event.queryStringParameters.recipeId.length : 18;
      let ids = `'${event.multiValueQueryStringParameters.recipeId[0]}'`;
      
      if (event.multiValueQueryStringParameters.recipeId.length > 1) {
        event.multiValueQueryStringParameters.recipeId.splice(0,1);
        for (const i of event.multiValueQueryStringParameters.recipeId) {
          ids += ` OR RecipeId = '${i}'`
        }
      }
      
      const sql = `SELECT * FROM recipes_kaggle WHERE RecipeId = ${ids} LIMIT 18`;
      const [res, ] = await connection.execute(sql);
      const response = {
        statusCode: 200,
        headers: {
          'Access-Control-Allow-Origin':'*',
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(res)
      };
      
      connection.end();
      return response;
    } else if (typeof event.queryStringParameters.ingredient !== "undefined") {
      if (event.queryStringParameters.ingredient === '') {
        const sql = `SELECT Ingredients from recipes_kaggle LIMIT 20`;
        const [res, ] = await connection.execute(sql);
        const response = {
          statusCode: 200,
          headers: {
            'Access-Control-Allow-Origin':'*',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(res)
        };
      
        connection.end();
        return response;
      } else {
        const sql = `select distinct Ingredient from recipe_ingredients where Ingredient like '%${event.queryStringParameters.ingredient}%`;
        const [res, ] = await connection.execute(sql);
        const response = {
          statusCode: 200,
          headers: {
            'Access-Control-Allow-Origin':'*',
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(res)
        };
      
        connection.end();
        return response;
      }
    }
  }

  const sql = `SELECT * FROM recipes_kaggle ORDER BY RAND() LIMIT 18`;
  const [res, ] = await connection.execute(sql);
  const response = {
    statusCode: 200,
    headers: {
      'Access-Control-Allow-Origin':'*',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(res)
  };
  
  connection.end();
  return response;
};
